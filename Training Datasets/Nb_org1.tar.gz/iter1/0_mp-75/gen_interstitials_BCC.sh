#!/bin/bash

# SET Potential Specific Parameters

home=$PWD

At=Nb

l_a1=3.32

mkdir interstitials_BCC2

cd interstitials_BCC2

mkdir db100
mkdir db110
mkdir db111
mkdir interOh
mkdir interTd
mkdir crowdion

# Populate Relaxed Structures and Lammps input FROM DOI: 10.1103/PhysRevB.54.6941
cd db100
N=2
atomsk --create bcc ${l_a1} ${At} -duplicate ${N} ${N} ${N} -remove-atoms 1 -add-atom ${At} at $(echo "0.38*${l_a1}" | bc) 0.0 0.0 -add-atom ${At} at $(echo "-0.38*${l_a1}" | bc) 0.0 0.0 POSCAR
cd ..

cd db110
atomsk --create bcc ${l_a1} ${At} -duplicate ${N} ${N} ${N} -remove-atom 1 -add-atom ${At} at $(echo "0.25*${l_a1}" | bc) $(echo "0.25*${l_a1}" | bc)  0.0 -add-atom ${At} at $(echo "-0.25*${l_a1}" | bc) $(echo "-0.25*${l_a1}" | bc)  0.0 POSCAR
cd ..

cd db111
#N=2
atomsk --create bcc ${l_a1} ${At} -duplicate ${N} ${N} ${N} -remove-atom 1 -add-atom ${At} at $(echo "0.22*${l_a1}" | bc) $(echo "0.22*${l_a1}" | bc) $(echo "-0.22*${l_a1}" | bc) -add-atom ${At} at $(echo "-0.22*${l_a1}" | bc) $(echo "-0.22*${l_a1}" | bc) $(echo "0.22*${l_a1}" | bc) POSCAR
cd ..

cd crowdion
#N=2
atomsk --create bcc ${l_a1} ${At} -duplicate ${N} ${N} ${N} -add-atom ${At} at $(echo "0.25*${l_a1}" | bc) $(echo "0.25*${l_a1}" | bc) $(echo "0.25*${l_a1}" | bc) POSCAR
cd ..

cd interOh
#N=2
atomsk --create bcc ${l_a1} ${At} -duplicate ${N} ${N} ${N} -add-atom ${At} at 0.0 $(echo "0.50*${l_a1}" | bc) $(echo "0.50*${l_a1}" | bc) POSCAR
cd ..

cd interTd
#N=2
atomsk --create bcc ${l_a1} ${At} -duplicate ${N} ${N} ${N} -add-atom ${At} at $(echo "0.50*${l_a1}" | bc) $(echo "0.25*${l_a1}" | bc) 0.0 POSCAR
cd ..


