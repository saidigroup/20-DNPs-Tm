#!/bin/bash

# SET Potential Specific Parameters

home=$PWD

At=Mg

l_a4=3.2094
l_c=5.13


mkdir interstitials_HCP2

cd interstitials_HCP2


# Make Relaxed Directories
mkdir db
mkdir dbB
mkdir dbP
mkdir dbPP
mkdir dbP2
mkdir crowdion
mkdir crowdionB
mkdir crowdionB2
mkdir crowdionP
mkdir interOh
mkdir interOhB
mkdir interTd
mkdir interTdB

# Populate Relaxed Structures and Lammps input
cd db
N=2
posx_a=0.0
posy_a=0.0
posz_a=$(echo "$l_c * 0.23" | bc )
posx_b=0.0
posy_b=0.0
posz_b=$(echo "$l_c * -0.23" | bc)
atomsk --create hcp ${l_a4} ${l_c} ${At} -duplicate ${N} ${N} ${N} -remove-atom 1 -add-atom ${At} at ${posx_a} ${posy_a} ${posz_a} -add-atom ${At} at ${posx_b} ${posy_b} ${posz_b} POSCAR
cd ..

cd dbB
#N=2
posx_a=$(echo  "0.52 * $l_a4" | bc)
posy_a=$(echo "-0.22 * $l_a4" | bc)
posz_a=0.0
posx_b=$(echo "-0.31 * $l_a4" | bc)
posy_b=$(echo "0.07 * $l_a4" | bc)
posz_b=0.0
atomsk --create hcp ${l_a4} ${l_c} ${At} -duplicate ${N} ${N} ${N} -remove-atom 1 -add-atom ${At} at ${posx_a} ${posy_a} ${posz_a} -add-atom ${At} at ${posx_b} ${posy_b} ${posz_b} POSCAR
cd ..

cd dbP
#N=2
posx_a=$(echo "0.24 * $l_a4" | bc)
posy_a=$(echo "0.04 * $l_a4" | bc)
posz_a=$(echo "0.21 * $l_c" | bc)
posx_b=$(echo "-0.19 * $l_a4" | bc)
posy_b=$(echo "0.03 * $l_a4" | bc)
posz_b=$(echo "-0.21 * $l_c" | bc)
atomsk --create hcp ${l_a4} ${l_c} ${At} -duplicate ${N} ${N} ${N} -remove-atom 1 -add-atom ${At} at ${posx_a} ${posy_a} ${posz_a} -add-atom ${At} at ${posx_b} ${posy_b} ${posz_b} POSCAR
cd ..

cd dbPP
#N=2
posx_a=$(echo "-0.28 * $l_a4" | bc)
posy_a=$(echo "0.06 * $l_a4" | bc)
posz_a=$(echo "0.15 * $l_c" | bc)
posx_b=$(echo "-0.28 * $l_a4" | bc)
posy_b=$(echo "0.06 * $l_a4" | bc)
posz_b=$(echo "-0.15 * $l_c" | bc)
atomsk --create hcp ${l_a4} ${l_c} ${At} -duplicate ${N} ${N} ${N} -remove-atom 1 -add-atom ${At} at ${posx_a} ${posy_a} ${posz_a} -add-atom ${At} at ${posx_b} ${posy_b} ${posz_b} POSCAR
cd ..

cd dbP2
#N=2
posx_a=$(echo "0.10 * $l_a4" | bc)
posy_a=$(echo "0.10 * $l_a4" | bc)
posz_a=$(echo "0.22 * $l_c" | bc)
posx_b=$(echo "-0.12 * $l_a4" | bc)
posy_b=$(echo "-0.12 * $l_a4" | bc)
posz_b=$(echo "-0.21 * $l_c" | bc)
atomsk --create hcp ${l_a4} ${l_c} ${At} -duplicate ${N} ${N} ${N} -remove-atom 1 -add-atom ${At} at ${posx_a} ${posy_a} ${posz_a} -add-atom ${At} at ${posx_b} ${posy_b} ${posz_b} POSCAR
cd ..

cd interOh
#N=2
posx=$(echo "0.66667 * $l_a4" | bc)
posy=$(echo "-0.3333 * $l_a4" | bc)
posz=0.0
atomsk --create hcp ${l_a4} ${l_c} ${At} -duplicate ${N} ${N} ${N} -add-atom ${At} at ${posx} ${posy} ${posz} POSCAR
cd ..

cd interOhB
#N=2
posx=$(echo "0.66667 * $l_a4" | bc)
posy=$(echo "-0.3333 * $l_a4" | bc)
posz=$(echo "0.25 * $l_c" | bc)
atomsk --create hcp ${l_a4} ${l_c} ${At} -duplicate ${N} ${N} ${N} -add-atom ${At} at ${posx} ${posy} ${posz} POSCAR
cd ..

cd interTd
#N=2
posx=0.0
posy=0.0
posz=$(echo "0.375 * $l_c" | bc)
atomsk --create hcp ${l_a4} ${l_c} ${At} -duplicate ${N} ${N} ${N} -add-atom ${At} at ${posx} ${posy} ${posz} POSCAR
cd ..

cd interTdB
#N=2
posx=0.0
posy=0.0
posz=$(echo "0.5 * $l_c" | bc)
atomsk --create hcp ${l_a4} ${l_c} ${At} -duplicate ${N} ${N} ${N} -add-atom ${At} at ${posx} ${posy} ${posz} POSCAR
cd ..

cd crowdion
#N=2
posx=$(echo "0.16667 * $l_a4" | bc)
posy=$(echo "0.16667 * $l_a4" | bc)
posz=$(echo "0.25 * $l_c" | bc)
atomsk --create hcp ${l_a4} ${l_c} ${At} -duplicate ${N} ${N} ${N} -add-atom ${At} at ${posx} ${posy} ${posz} POSCAR
cd ..

cd crowdionB
#N=2
posx=$(echo "0.25 * $l_a4" | bc)
posy=0.0
posz=0.0
atomsk --create hcp ${l_a4} ${l_c} ${At} -duplicate ${N} ${N} ${N} -add-atom ${At} at ${posx} ${posy} ${posz} POSCAR
cd ..

cd crowdionB2
#N=2
posx=$(echo "0.62 * $l_a4" | bc)
posy=$(echo "-0.25 * $l_a4" | bc)
posz=$(echo "0.08 * $l_c" | bc)
atomsk --create hcp ${l_a4} ${l_c} ${At} -duplicate ${N} ${N} ${N} -add-atom ${At} at ${posx} ${posy} ${posz} POSCAR
cd ..

cd crowdionP
#N=2
posx=$(echo "0.31 * $l_a4" | bc)
posy=$(echo "0.02 * $l_a4" | bc)
posz=$(echo "0.25 * $l_c" | bc)
atomsk --create hcp ${l_a4} ${l_c} ${At} -duplicate ${N} ${N} ${N} -add-atom ${At} at ${posx} ${posy} ${posz} POSCAR
cd ..

